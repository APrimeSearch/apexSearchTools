//
// compile: g++ -m32 `root-config --libs` -I`root-config --incdir` -o LHEtoPGScut LHEtoPGScut.cc
//

#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <cmath>
#include <string>
#include <vector>
#include <cassert>
#include "TLorentzVector.h"

using namespace std;

int nParticlesPrint;
int NDUMMY;

double pi=3.141592;

class SpectrometerCut
{
public:
  SpectrometerCut(double xmin,double xmax, double ymax, double pmin);
  bool pass(vector<TLorentzVector> momenta, vector<int> signs);

private:
  double xmin_, xmax_, ymax_, pmin_;
  const static bool DEBUG;
};

enum Charge {PLUS=0,MINUS=1};
Charge charge(int i) { return (i>0) ? PLUS :  MINUS; };

class SpectrometerCutMainz
{
public:
  SpectrometerCutMainz(Charge qRef);
  void setSpec(Charge q, double xmin,double xmax, double ymax, double pmin, double pmax);
  vector<double > rotatePass(vector<TLorentzVector> momenta, vector<Charge> signs) const;
  bool pass(vector<TLorentzVector> momenta, vector<Charge> signs, Charge qref) const;
  void doRotate(bool dr) { if(dr==false) ncopy_=0;  };
  static int sgn(Charge q) { if(q==PLUS) return 1; else return -1; }; 

  int ncopy() { return ncopy_;}
  double xmin(Charge q) const  { return xmin_[int(q)];}
  double xmax(Charge q) const  { return xmax_[int(q)];}
  double ymax(Charge q) const  { return ymax_[int(q)];}
  double pmin(Charge q) const  { return pmin_[int(q)];}
  double pmax(Charge q) const  { return pmax_[int(q)];}


  Charge qRef_;
  int ncopy_;
  double phi_max_;

  vector<double> xmin_, xmax_, ymax_, pmin_, pmax_;
  const static bool DEBUG;
};

const bool SpectrometerCut::DEBUG=false;
const bool SpectrometerCutMainz::DEBUG=false;



void getP(istream& ins, TLorentzVector& part)
{
  double px,py,pz,pt,mass;
  ins >> px >> py >> pz >> pt >> mass;
  
  part=TLorentzVector(px, py, pz, pt);
  //  cout << "reading particle:  x " << part.Px() << " y " <<  part.Py() << " z " <<  part.Pz() <<  " E " <<  part.E() << " mass " << part.M() << endl;
}

void printP(ostream& outs, TLorentzVector& part, string typeString, int pid,double Ebeam, int ipart)
{

        outs << ipart << setw(7) << typeString
             << " " << setw(10) << setprecision(5) << part.Eta()
             << " " << setw(10) << setprecision(5) << part.Phi()
             << " " << setw(10) << setprecision(5) << part.Pt()
             << " " << setw(10) << setprecision(5) << part.M()
             << " " << setw(6) << setprecision(2) << (pid>0? -1 : 1) << ".00";
        outs << " " << setw(6) << setprecision(2) << Ebeam;
        for(int i=0; i<NDUMMY-1; ++i) {
          outs << setw(6) << "0.00";
        }
        outs << endl;

}

class Event
{
public:
  //  ~Event() { cout << " -- end event -- " << endl;}

  void addP(TLorentzVector& part, string typeString, int pid, double Ebeam);
  void print(ostream& outs, double rotAngle);

private:
  vector<TLorentzVector> particles_;
  vector<string> typeString_;
  vector<int> pid_;
  double Ebeam_;
  
};
  
void Event::print(ostream& outs, double rotAngle)
{
  for(int i=0; i<particles_.size(); ++i) {
    TLorentzVector rotParticle(particles_[i]);
    rotParticle.RotateZ(rotAngle);

    printP(outs, rotParticle, typeString_[i], pid_[i], Ebeam_, i+1);
  }

  //  cout << " ---- good event printed ---- " << endl;
}

void Event::addP(TLorentzVector& part, string typeString, int pid, double Ebeam)
{
  particles_.push_back(part);
  typeString_.push_back(typeString);
  pid_.push_back(pid);
  Ebeam_=Ebeam;
  
  /*if(true) {if(abs(pid)==11)
      cout << setw(4) << pid << ": p=" << setw(6) << part.P() << " theta=" << setw(6) << part.Theta() << " phi=" << setw(6) << part.Phi() << endl;
      }*/
}


bool readEvent(istream& ins, ostream& passouts, int& nev, int& nevpass, SpectrometerCutMainz& cutfunc)
{
  string nextline;
  string ignoreRestOfLine;

  do {
    getline(ins, nextline);
    //    cout << "NEXT : " << nextline << endl;
    if(ins.eof()) return false; // failed to find an event
  } while (nextline.find("<event>") == string::npos);// continue while test string isn't found.
  
  //  cout << "AN EVENT: " << endl;
  // cout << "0" << setw(5) << nevpass+1 << setw(7) <<  "9999" << endl; 



  // assume there's an event coming next.
  int npart;
  ins >> npart;
  getline(ins, ignoreRestOfLine);

  //  cout << " NPART = " << npart << " (rest of line ignored ) " << endl;
  
  TLorentzVector initialNucMomentum;
  TLorentzVector finalNucMomentum;
  TLorentzVector APrimeMomentum;
  TLorentzVector initialElectronMomentum;
  vector<TLorentzVector> outgoingMomenta;
  vector<Charge> outgoingCharges;
  double EBeam;
  Event ev;
  TVector3 labBoost;
  nParticlesPrint=0;
  NDUMMY=4;
  for(int i=0; i< npart; ++i)
    {
      int pid, stat, idummy; 
      ins >> pid >> stat >> idummy >> idummy >> idummy >> idummy;

      if(pid==999) {
        // vertex isn't counted in npart.
        ++npart;
      }


      if((pid==611 || pid==11) && stat==-1) { // it's the incoming "electron"
        getP(ins, initialElectronMomentum);
      }
      if(pid==-623 && stat==-1) { // it's the incoming "nucleon"
        getP(ins, initialNucMomentum);
        labBoost= -initialNucMomentum.BoostVector();
        initialNucMomentum.Boost(labBoost);
        initialElectronMomentum.Boost(labBoost);
        EBeam=initialElectronMomentum.E();
      }

      if(pid==-623 && stat==1) { // it's the outgoing "nucleon"
        ++nParticlesPrint;
        getP(ins, finalNucMomentum);
        finalNucMomentum.Boost(labBoost);
        ev.addP(finalNucMomentum,"4", pid,EBeam);

        ++nParticlesPrint;
        TLorentzVector q = finalNucMomentum-initialNucMomentum;
        //        cout << " q px=" << q.Px() << " py=" << q.Py() << " pz=" << q.Pz();
        ev.addP(q,"5", pid,EBeam);

      }

      if(pid==622) { // it's the Aprime
        ++nParticlesPrint;
        getP(ins, APrimeMomentum);
        APrimeMomentum.Boost(labBoost);
        ev.addP(APrimeMomentum,"0", pid,EBeam);
      }
      
      if(abs(pid)==611 && stat==1) { // it's an outgoing beam electron 
        ++nParticlesPrint;
        TLorentzVector eMomentum;
        getP(ins,eMomentum);
        eMomentum.Boost(labBoost);
        ev.addP(eMomentum,"2",pid,EBeam);   // reversed to agree with the conventions in new code

        outgoingMomenta.push_back(eMomentum);
        outgoingCharges.push_back(charge(-pid));
      }
      

      if(abs(pid)==11 && stat==1) { // it's an electron 
        ++nParticlesPrint;
        TLorentzVector eMomentum;
        getP(ins,eMomentum);
        eMomentum.Boost(labBoost);
        ev.addP(eMomentum,"2",pid,EBeam);


        outgoingMomenta.push_back(eMomentum);
        outgoingCharges.push_back(charge(-pid));

      }

      if(abs(pid)==15) { // it's an electron (actually a tau)
        ++nParticlesPrint;
        TLorentzVector eMomentum;
        getP(ins,eMomentum);
        eMomentum.Boost(labBoost);
        ev.addP(eMomentum,"2",pid,EBeam);   // reversed to agree with the conventions in new code
      } 

      getline(ins, ignoreRestOfLine); // ignore the stuff in the rest of the line.
    }

  //    cout << EBeam << "   " << APrimeMomentum.M() << "  " << APrimeMomentum.E()/EBeam << " " 
  //         << APrimeMomentum.Pt()/APrimeMomentum.Pz()   << "  " << -(finalNucMomentum-initialNucMomentum).M2() << endl;

  //  cout << " i am happy" << endl;

  // if everything succeeded, let calling function know that you're happy.
  vector<double> goodRotAngles=cutfunc.rotatePass(outgoingMomenta,outgoingCharges);
		
  for(int i=0; i<goodRotAngles.size(); ++i) {
      //      cout << outs.str();
      passouts << "0" << setw(5) << nevpass+1 << setw(7) <<  "9999" << endl; 
      ev.print(passouts, goodRotAngles[i]);  //// THIS NEEDS TO BE COMPLETELY REWRITTEN -- CAN'T WRITE EVENT UNTIL WE KNOW WHAT TO PHASE IT BY.
      ++nevpass;
    }
	
  ++nev;

  return true;
}

void printUsage()
{
  cerr << "LHEtoPGS [-x0 xmin- xmin+] [-x1 xmax- xmax+] [-y ymax- ymax+] [-p0 pmin- pmin+] [-p1 pmax- pmax+] <inputfile> <outputfile>" << endl;
  return;
}

double atod(const string str)
{
  istringstream s(str);
  double temp;

  s >> temp;
  return temp;
}

int main(int argc, char* const argv[] )
{

  int numOpt=0;
  string inputFileName;
  string outputFileName;
  
  bool useHPGS=false, debug=false;


  // default spectrometer params: USING SETUP 1 (which appears to be used in fig. 6
  double x0A=0.089, p0A=1.131,  dpA=0.04*p0A, dxA=0.017, dyA=0.037; // A=positive
  double x0B=0.089, p0B=1.131, dpB=0.04*p0B, dxB=0.017, dyB=0.037; // B=negative

  //  true spec. settings
  //  double x0A=22.8*pi/180., p0A=0.338,  dpA=0.1*p0A,   dxA=0.10, dyA=0.07; // A=positive
  //  double x0B=15.2*pi/180., p0B=0.4699, dpB=0.075*p0B, dxB=0.02, dyB=0.07; // B=negative

  //double xmin_p=0.0, xmax_p=100.0, ymax_p=100.0, pmin_p=0.0, pmax_p=100.0;
  //double xmin_m=0.0, xmax_m=100.0, ymax_m=100.0, pmin_m=0.0, pmax_m=100.0;

  double xmin_p=x0A-dxA, xmax_p=x0A+dxA, ymax_p=dyA, pmin_p=p0A-dpA, pmax_p=p0A+dpA;
  double xmin_m=x0B-dxB, xmax_m=x0B+dxB, ymax_m=dyB, pmin_m=p0B-dpB, pmax_m=p0B+dpB;

  Charge qRef=PLUS;
  bool doRot=true;

  while(argc-numOpt>1 && argv[1+numOpt][0]=='-') {
    numOpt++;
    if(strcmp(argv[numOpt],"-p0")==0) {
      pmin_m=atod(argv[1+numOpt]);
      pmin_p=atod(argv[2+numOpt]);
      numOpt+=2;
    }
    else if(strcmp(argv[numOpt],"-p1")==0) {
      pmax_m=atod(argv[1+numOpt]);
      pmax_p=atod(argv[2+numOpt]);
      numOpt+=2;
    }
    else if(strcmp(argv[numOpt],"-y")==0) {
      ymax_m=atod(argv[1+numOpt]);
      ymax_p=atod(argv[2+numOpt]);
      numOpt+=2;
    }
    else if(strcmp(argv[numOpt],"-x0")==0) {
      xmin_m=atod(argv[1+numOpt]);
      xmin_p=atod(argv[2+numOpt]);
      numOpt+=2;
    }
    else if(strcmp(argv[numOpt],"-x1")==0) {
      xmax_m=atod(argv[1+numOpt]);
      xmax_p=atod(argv[2+numOpt]);
      numOpt+=2;
    }
    else if(strcmp(argv[numOpt],"-r")==0) {
      int i=atoi(argv[1+numOpt]);
      if(i==0){
	doRot=false;
      }
      else qRef=charge(i);
      numOpt++;
    }
    
    else  {
      cerr << "Unknown option " << argv[numOpt] << endl;
      printUsage();
      return 1;
    }
  } //End options loop 

  SpectrometerCutMainz mainzSpec(qRef);
  mainzSpec.setSpec(MINUS,xmin_m,xmax_m,ymax_m,pmin_m,pmax_m);
  mainzSpec.setSpec(PLUS,xmin_p,xmax_p,ymax_p,pmin_p,pmax_p);
  mainzSpec.doRotate(doRot);

  if(argc==3+numOpt) {
    inputFileName=argv[1+numOpt];
    outputFileName=argv[2+numOpt];
  }
  else {
    printUsage();
    return 1;
  }

  ifstream ins(inputFileName.c_str());
  ofstream outs(outputFileName.c_str());
  
  if(!ins.good()){
    cerr << " ERROR: COULD NOT OPEN " << inputFileName << endl;
    return 0;
  }

  
  if(!outs.good()){
    cerr << " ERROR: COULD NOT OPEN " << outputFileName << endl;
    return 0;
  }

  // record provenance
  outs << "# PROVENANCE: " ;
  for(int i=0; i<argc; ++i)
    {
      outs << argv[i] << "  ";
    }
  outs << endl;

  cout << "  xmin_p=" << xmin_p << "  xmax_p=" << xmax_p << "  ymax_p=" << ymax_p << "  pmin_p=" << pmin_p << "  pmax_p=" << pmax_p << endl;
  cout << "  xmin_m=" << xmin_m << "  xmax_m=" << xmax_m << "  ymax_m=" << ymax_m << "  pmin_m=" << pmin_m << "  pmax_m=" << pmax_m << endl;

  outs << "#   xmin_p=" << xmin_p << "  xmax_p=" << xmax_p << "  ymax_p=" << ymax_p << "  pmin_p=" << pmin_p << "  pmax_p=" << pmax_p << endl;
  outs << "#   xmin_m=" << xmin_m << "  xmax_m=" << xmax_m << "  ymax_m=" << ymax_m << "  pmin_m=" << pmin_m << "  pmax_m=" << pmax_m << endl;


  // end provenance.

  // the actual loop

  int nev=0;
  int nevpass=0;

  outs << "  #  typ      eta    phi      pt    jmas  ntrk  btag   had/em  dum1  dum2" << endl;
  while( nev < 5000000 && readEvent(ins, outs, nev, nevpass, mainzSpec)){
    if(nev%5000==0) cout << " read " << nev << " events (" << nevpass << " pass: " << 100.0*nevpass/nev << "%)" << endl;
  }

  // record statistics
  outs << "# STATISTICS: " << nevpass << " EVENTS WRITTEN OUT OF " << nev << " EVENTS READ, " << mainzSpec.ncopy() << " copies." << endl;
  outs << "# STATISTICS:      TRUE PASS PERCENTAGE " << 100.0*nevpass/nev / max(mainzSpec.ncopy(),1) << "%" << endl;
  cout << "# STATISTICS: " << nevpass << " EVENTS WRITTEN OUT OF " << nev << " EVENTS READ, " << mainzSpec.ncopy() << " copies." << endl;
  cout << "# STATISTICS:      TRUE PASS PERCENTAGE " << 100.0*nevpass/nev / max(mainzSpec.ncopy(),1) << "%" << endl;
  //ADD "TRUE ACCEPTANCE PER
  // end statistics
  

}


//////////////////////////////////////////////
//////////     USED CLASS FUNCTIONS //////////
//enum Charge {PLUS=0,MINUS=1};

/*class SpectrometerCutMainz
{
public:
  SpectrometerCutMainz();
  void setSpec(Charge q, double xmin,double xmax, double ymax, double pmin, double pmax);
  bool rotatePass(vector<TLorentzVector> momenta, vector<int> signs, Charge chargeToRotate);
  bool pass(vector<TLorentzVector> momenta, vector<int> signs);

  private:
  double xmin_[2], xmax_[2], ymax_[2], pmin_[2], pmax_[2];
  const static bool DEBUG;
};

*/
 
SpectrometerCutMainz::SpectrometerCutMainz(Charge qref):
  pmax_(2,0.),  // Ensures that nothing will work until initialized
  pmin_(2,10.),
  xmax_(2,0.),
  xmin_(2,0.),
  ymax_(2,100.),
  qRef_(qref),
  ncopy_(1),
  phi_max_(pi) {}

void SpectrometerCutMainz::setSpec(Charge q, double xmin,double xmax, double ymax, double pmin, double pmax)
{
  int qi(q);
  xmin_[qi]=xmin;
  xmax_[qi]=xmax;
  assert(xmax>xmin);
  ymax_[qi]=ymax;
  pmin_[qi]=pmin;
  pmax_[qi]=pmax;
  assert(pmin<pmax);

  if(q==qRef_) {
    phi_max_ = (xmin==0? 2*pi : atan(ymax/xmin));
    ncopy_ = floor(2*pi/(2*phi_max_));
    //cout << " NCopy " << ncopy_ << endl;
  }

  return;
}

vector<double> SpectrometerCutMainz::rotatePass(vector<TLorentzVector> trueMomenta, vector<Charge> signs) const
{
  /* Procedure:
     1) Interpret x_min/max as theta_min/max, determine central theta0
     2) use inner theta to derive phi_max = arctan(y_max/theta_min).  
     
                            /|   ^
                         /   |   ymax
                      /phi)  |   |
                    ---------|   v
                    <-theta0->
     3) Define ncopy = floor(2pi/(2 phi_max)) = # of full copies of 2*phi_max regions you can fit in an annulus
     4) Loop over particles of desired charge, let p be its momentum
        a] Find nshift = floor[phi(p) / (2 phi_max)]
	   This is 0 if phi is between 0 and 2 phi_max, etc.
	b] If nshift < ncopy, check whether event passes after rotation 
           by -(nshift*2+1)*phi_max.  The +1 brings the center of the 
           nominal 'spectrometer' to phi = 0.

     **Note: using theta_min in the determination of phi_max introduces
        'dead space' between copies of the spectrometer, but allows us to
        use rectangular acceptance
  */
  vector<double> passRots(0);

  if(ncopy_==0) {
    if(pass(trueMomenta, signs, qRef_))
      passRots.push_back(0.);  
  }
  else {
    for(int i=0; i<signs.size(); ++i) {
      if(signs[i]==qRef_) { // try to rotate this guy into 'nominal spectrometer'
	int nshift = floor(trueMomenta[i].Phi() / (2*phi_max_));
	if(nshift < ncopy_) { // rotate by nshift
	  vector<TLorentzVector> rotMomenta(trueMomenta);
	  double rotAngle=-(1+nshift*2)*phi_max_;
	  for(int j=0; j<rotMomenta.size(); ++j) {	 
	    rotMomenta[j].RotateZ(rotAngle);
	  }
	  assert(fabs(rotMomenta[i].Phi())<phi_max_);  // the rotated momentum i should be w.in phi_max whenever n_shift < n_copy.
	  if(pass(rotMomenta, signs, qRef_))
	    passRots.push_back(rotAngle);
	}
      }
    }
  }
  return passRots;
}

bool SpectrometerCutMainz::pass(vector<TLorentzVector> momenta, vector<Charge> signs, Charge qref) const
{
  int pass[2]={0,0};
  
  int npart=momenta.size();

  if(DEBUG) cout << " hi npart = " << npart << endl;

  if(npart<2) return false;
  
  for(int i=0; i<npart; ++i)
    {
      double thx=atan(momenta[i].Px()/momenta[i].Pz());
      double thy=atan(momenta[i].Py()/momenta[i].Pz());
      double P = momenta[i].P();
      Charge q = signs[i];
      int sgnX=sgn(q)*sgn(qRef_);

      if(DEBUG) cerr << "(" << thx << "  " ;
      if(DEBUG) cerr << thy << ")  " ;



      if(P>pmin(q) && P < pmax(q) && abs(thy) < ymax(q)) {
        if(DEBUG) cerr << "ok" << endl;
        if(sgnX*thx>xmin(q) && sgnX*thx<xmax(q)) {       
          pass[int(q)]++;
          if(DEBUG) cerr << " pass[" << q<< "]=" << pass[int(q)] << endl;
        }
	/*	else {
	  cout << " thetaX fail (" << sgn(q) << ") " << thx << endl;
	  }*/
      }
      /*      else if(P>0.7){
	if(P<pmin(q))
	  cout << "   low  P   " << P << "  ("<< sgn(q) << ")" << endl;
	if(P>pmax(q))
	  cout << "   high P   " << P << "  ("<< sgn(q) << ")" << endl;
	if(abs(thy) > ymax(q))
	  cout << "   thy fail " << thy << " ("<< sgn(q) << ")" << endl;
	  }*/
    }
  /*
  if(pass[PLUS] ==0) cout << " NO PLUS" << endl;
    
  if(pass[MINUS] ==0) cout << " NO MINUS" << endl;*/

  if(DEBUG) cerr << endl;
  if(DEBUG) if(pass[PLUS]>0 || pass[MINUS] > 0) cerr << "passP= " << pass[PLUS] << "passM= " << pass[MINUS] << endl;

  if(pass[int(PLUS)]*pass[(MINUS)]>=1) {
    if(DEBUG) cerr << "PASS!";
    return true;
  }
  else return false;
}




//////////////////////////////////////////////
//////////  OBSOLETE CLASS FUNCTIONS //////////

 
SpectrometerCut::SpectrometerCut(double xmin,double xmax, double ymax, double pmin):
  xmin_(xmin),
  xmax_(xmax),
  ymax_(ymax),
  pmin_(pmin) {return;}

bool SpectrometerCut::pass(vector<TLorentzVector> momenta, vector<int> signs)
{
  int passP=0;
  int passM=0;
  
  int npart=momenta.size();

  if(DEBUG) cout << " hi npart = " << npart << endl;

  if(npart<2) return false;
  


  for(int i=0; i<npart; ++i)
    {
      double thx=atan(momenta[i].Px()/momenta[i].Pz());
      double thy=atan(momenta[i].Py()/momenta[i].Pz());
      double P = momenta[i].P();

      if(DEBUG) cerr << "(" << thx << "  " ;
      if(DEBUG) cerr << thy << ")  " ;

      if(P>pmin_ && abs(thy) < ymax_) {
        if(DEBUG) cerr << "ok" << endl;
        if(thx>xmin_ && thx<xmax_) {       
          passP=(abs(passP)+1)*signs[i];
          if(DEBUG) cerr << " passP " << passP << endl;
        }
        if(thx< -xmin_ && thx> - xmax_) {
          passM=(abs(passM)+1)*signs[i];
          if(DEBUG) cerr << " passM " << passM << endl;
        }
      }
    }

  if(DEBUG) cerr << endl;
  if(DEBUG) if(passP>0 || passM > 0) cerr << "passP= " << passP << "passM= " << passM << endl;

  if(passP*passM==-1 || abs(passP*passM)>1) {
    if(DEBUG) cerr << "PASS!";
    return true;
  }
  else return false;
}

