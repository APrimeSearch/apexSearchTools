#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <string>
#include "TLorentzVector.h"

using namespace std;

int nParticlesPrint;
int NDUMMY;

void getP(istream& ins, TLorentzVector& part)
{
  double px,py,pz,pt,mass;
  ins >> px >> py >> pz >> pt >> mass;
  
  part=TLorentzVector(px, py, pz, pt);
  //  cout << "reading particle:  x " << part.Px() << " y " <<  part.Py() << " z " <<  part.Pz() <<  " E " <<  part.E() << " mass " << part.M() << endl;
}

void printP(ostream& outs, TLorentzVector& part, string typeString, int pid,double Ebeam)
{

        outs << nParticlesPrint << setw(7) << typeString
             << " " << setw(8) << setprecision(3) << part.Eta()
             << " " << setw(8) << setprecision(3) << part.Phi()
             << " " << setw(8) << setprecision(3) << part.Pt()
             << " " << setw(6) << setprecision(3) << part.M()
             << " " << setw(6) << setprecision(2) << (pid>0? 1 : -1) << ".00";
        outs << " " << setw(6) << setprecision(2) << Ebeam;
        for(int i=0; i<NDUMMY-1; ++i) {
          outs << setw(6) << "0.00";
        }
        outs << endl;

}

bool readEvent(istream& ins, ostream& outs, int nev)
{
  string nextline;
  string ignoreRestOfLine;
  do {
    getline(ins, nextline);
    //    cout << "NEXT : " << nextline << endl;
    if(ins.eof()) return false; // failed to find an event
  } while (nextline.find("<event>") == string::npos);// continue while test string isn't found.
  
  //  cout << "AN EVENT: " << endl;
  // cout << "0" << setw(5) << nev+1 << setw(7) <<  "9999" << endl; 
  outs << "0" << setw(5) << nev+1 << setw(7) <<  "9999" << endl; 


  // assume there's an event coming next.
  int npart;
  ins >> npart;
  getline(ins, ignoreRestOfLine);

  //  cout << " NPART = " << npart << " (rest of line ignored ) " << endl;
  
  TLorentzVector initialNucMomentum;
  TLorentzVector finalNucMomentum;
  TLorentzVector APrimeMomentum;
  TLorentzVector initialElectronMomentum;
  double EBeam;
  TVector3 labBoost;
  nParticlesPrint=0;
  NDUMMY=4;
  for(int i=0; i< npart; ++i)
    {
      int pid, stat, idummy; 
      ins >> pid >> stat >> idummy >> idummy >> idummy >> idummy;

      if(pid==999) {
        // vertex isn't counted in npart.
        ++npart;
      }


      if((pid==611 || pid==11) && stat==-1) { // it's the incoming "electron"
        getP(ins, initialElectronMomentum);
      }
      if(pid==-623 && stat==-1) { // it's the incoming "nucleon"
        getP(ins, initialNucMomentum);
        labBoost= -initialNucMomentum.BoostVector();
        initialNucMomentum.Boost(labBoost);
        initialElectronMomentum.Boost(labBoost);
        EBeam=initialElectronMomentum.E();
      }

      if(pid==-623 && stat==1) { // it's the outgoing "nucleon"
        ++nParticlesPrint;
        getP(ins, finalNucMomentum);
        finalNucMomentum.Boost(labBoost);
        printP(outs,finalNucMomentum,"4", pid,EBeam);

        ++nParticlesPrint;
        TLorentzVector q = finalNucMomentum-initialNucMomentum;
        //        cout << " q px=" << q.Px() << " py=" << q.Py() << " pz=" << q.Pz();
        printP(outs,q,"5", pid,EBeam);

      }

      if(pid==622) { // it's the Aprime
        ++nParticlesPrint;
        getP(ins, APrimeMomentum);
        APrimeMomentum.Boost(labBoost);
        printP(outs,APrimeMomentum,"0", pid,EBeam);
      }
      
      if(abs(pid)==611 && stat==1) { // it's an outoging beam electron 
        ++nParticlesPrint;
        TLorentzVector eMomentum;
        getP(ins,eMomentum);
        eMomentum.Boost(labBoost);
        printP(outs,eMomentum,"2",pid,EBeam);   // reversed to agree with the conventions in new code
      }
      

      if(abs(pid)==11 && stat==1) { // it's an electron 
        ++nParticlesPrint;
        TLorentzVector eMomentum;
        getP(ins,eMomentum);
        eMomentum.Boost(labBoost);
        printP(outs,eMomentum,"1",pid,EBeam);
      }

      if(abs(pid)==15) { // it's an electron (actually a tau)
        ++nParticlesPrint;
        TLorentzVector eMomentum;
        getP(ins,eMomentum);
        eMomentum.Boost(labBoost);
        printP(outs,eMomentum,"2",pid,EBeam);   // reversed to agree with the conventions in new code
      } 

      getline(ins, ignoreRestOfLine); // ignore the stuff in the rest of the line.
    }

  //    cout << EBeam << "   " << APrimeMomentum.M() << "  " << APrimeMomentum.E()/EBeam << " " 
  //         << APrimeMomentum.Pt()/APrimeMomentum.Pz()   << "  " << -(finalNucMomentum-initialNucMomentum).M2() << endl;

  //  cout << " i am happy" << endl;

  // if everything succeeded, let calling function know that you're happy.
  return true;
}

void printUsage()
{
  cerr << "LHEtoPGS <inputfile> <outputfile>" << endl;
  return;
}

int main(int argc, char* const argv[] )
{

  int numOpt=0;
  string inputFileName;
  string outputFileName;
  
  bool useHPGS=false, debug=false;

  /* // copied example of option parsing
  while(argc-numOpt>1 && argv[1+numOpt][0]=='-') {
    numOpt++;
    if(strcmp(argv[numOpt],"-X")==0) {
      maxEvents=atoi(argv[1+numOpt]);
      numOpt++;
    }
    else if(strcmp(argv[numOpt],"-h")==0) {
      useHPGS=true;
    }
    else if(strcmp(argv[numOpt],"-d")==0) {
      debug=true;
    }
  } //End options loop  */

  if(argc==3+numOpt) {
    inputFileName=argv[1+numOpt];
    outputFileName=argv[2+numOpt];
  }
  else {
    printUsage();
    return 1;
  }

  ifstream ins(inputFileName.c_str());
  ofstream outs(outputFileName.c_str());
  
  if(!ins.good()){
    cerr << " ERROR: COULD NOT OPEN " << inputFileName << endl;
    return 0;
  }

  
  if(!outs.good()){
    cerr << " ERROR: COULD NOT OPEN " << outputFileName << endl;
    return 0;
  }


  // the actual loop

  int nev=0;

  outs << "  #  typ      eta    phi      pt    jmas  ntrk  btag   had/em  dum1  dum2" << endl;
  while( nev < 50000 && readEvent(ins, outs, nev)){
    ++nev;
    if(nev%1000==0) cout << " read " << nev << " events " << endl;
  }

  

}
